<?php include "include/header.php"; ?>
			<br/>
			<h1>Public Area!</h1>