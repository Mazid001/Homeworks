<?php include "../include/headerL.php"; ?>
<?php include "../sidebar/admin_sidebar.php"; ?>

			<h1>Welcome <?php echo $_SESSION["name"]; ?></h1>
